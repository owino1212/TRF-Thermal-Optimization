# ==============================================================================
# File: TRF_Script_Geometry_Generator.py
# Description: Autodesk Fusion 360 Python API script to generate the 3D 
#              computational domain geometry for a Tilting Rotary Furnace (TRF)
#              using propane fuel, including concentric material layers and 
#              virtual thermocouple sampling nodes.
# Author: Dalmas Ochola Owino
# License: Creative Commons Attribution 4.0 International (CC BY 4.0)
# ==============================================================================

import adsk.core, adsk.fusion, traceback

def run(context):
    ui = None
    try:
        app = adsk.core.Application.get()
        ui  = app.userInterface
        doc = app.documents.add(adsk.core.DocumentTypes.FusionDesignDocumentType)
        design = app.activeProduct
        rootComp = design.rootComponent

        # Internal dimensions in cm (Fusion 360 API internal unit is cm)
        L = 67.0            # Cylinder length: 670 mm
        r_outer = 30.0      # Outer diameter: 600 mm -> radius 300 mm
        t_steel = 1.5       # A36 Steel shell thickness: 15 mm
        t_sand = 10.0       # Sand insulation layer thickness: 100 mm
        t_ref = 1.5         # Dense refractory backing thickness: 15 mm
        t_crucible = 1.0    # Baseline crucible wall thickness: 10 mm

        # 1. Sketch Concentric Layers
        sketches = rootComp.sketches
        xyPlane = rootComp.xYConstructionPlane
        sketch = sketches.add(xyPlane)
        circles = sketch.sketchCurves.sketchCircles

        # Radial boundaries from outer to inner
        r1 = r_outer                                # 30.0 cm
        r2 = r1 - t_steel                           # 28.5 cm
        r3 = r2 - t_sand                            # 18.5 cm
        r4 = r3 - t_ref                             # 17.0 cm
        r5 = r4 - t_crucible                        # 16.0 cm

        circles.addByCenterRadius(adsk.core.Point3D.create(0, 0, 0), r1)
        circles.addByCenterRadius(adsk.core.Point3D.create(0, 0, 0), r2)
        circles.addByCenterRadius(adsk.core.Point3D.create(0, 0, 0), r3)
        circles.addByCenterRadius(adsk.core.Point3D.create(0, 0, 0), r4)
        circles.addByCenterRadius(adsk.core.Point3D.create(0, 0, 0), r5)

        extrudes = rootComp.features.extrudeFeatures

        def extrude_layer(profile_idx, distance_cm, name):
            prof = sketch.profiles.item(profile_idx)
            ext_input = extrudes.createInput(prof, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
            distance = adsk.core.ValueInput.createByReal(distance_cm)
            ext_input.setDistanceExtent(False, distance)
            body = extrudes.add(ext_input).bodies.item(0)
            body.name = name
            return body

        # 2. Extrude Solid Bodies
        steel_body = extrude_layer(0, L, "Outer_Shell_A36_Steel")
        sand_body  = extrude_layer(1, L, "Sand_Insulation_Layer")
        ref_body   = extrude_layer(2, L, "Dense_Refractory_Backing")
        cruc_body  = extrude_layer(3, L, "Graphite_Crucible_Cavity")

        # 3. Create Virtual Thermocouple Construction Points
        c_points = rootComp.constructionPoints
        
        # TC-C: Core/Center (0, 0, 335 mm)
        pt_C = adsk.core.Point3D.create(0, 0, L / 2.0)
        c_points.add(c_points.createInputAtPoint(pt_C))

        # TC-I: Interior Near-Wall (1 mm inward from inner crucible wall)
        pt_I = adsk.core.Point3D.create(0, (r5 - 0.1), L / 2.0)
        c_points.add(c_points.createInputAtPoint(pt_I))

        # TC-S: Exterior Shell (0, 300 mm, 335 mm)
        pt_S = adsk.core.Point3D.create(0, r1, L / 2.0)
        c_points.add(c_points.createInputAtPoint(pt_S))

        ui.messageBox('TRF Geometry and Virtual Thermocouple Nodes Created Successfully.')

    except:
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))