1. Autodesk Fusion 360 CAD Model Specifications & Domains
To reproduce the 3D computational domain in Autodesk Fusion 360, configure the solid geometry parameters, concentric assembly layers, and virtual sampling nodes as defined in the study: 
Geometric Assembly & Material Layers
	Outer Shell (A36 Structural Steel): Hollow cylinder, length L=670" mm" , outer diameter ∅=600" mm" , shell wall thickness t_s=15" mm" . 
	Sand Insulation Layer: Concentric inner ring, thickness t_"ins" =100" mm" , thermal conductivity k_"sand" =0.25〖" W m" 〗^(-1) "K" ^(-1). 
	Dense Refractory Backing: Inner lining layer, thickness t_"ref" =15" mm" . 
	Interchangeable Crucible Cavity: Core functional domain, wall thickness t_c∈[10,15,20,25]" mm" . Tested geometries include Cylindrical, Conical, Flat-Base, and Sharp-Corner variants. 
Virtual Thermocouple Node Placement
	TC-C (Core/Center): x=0" mm",y=0" mm",z=335" mm"  (Centroid of internal charge volume). 
	TC-I (Interior Near-Wall): Positioned 1" mm"  inward from the inner crucible wall boundary. 
	TC-S (Exterior Shell): x=0" mm",y=300" mm",z=335" mm"  (Center of outer steel casing boundary). 
2. Spatial Discretization & Mesh Parameters
For repeated grid setup in Fusion 360 Simulation / FEA workspace, apply the validated Fine Mesh scheme to ensure grid independence: 
	Element Type: High-order 10-node unstructured tetrahedral solid elements (C^1-continuous thermal degree of freedom). 
	Total Mesh Elements: 542,800 elements (765,920 nodes). 
	Mean Element Aspect Ratio: 1.42 (Average Jacobian ratio 1.05). 
	Crucible Wall Refinement: Mean element size of 1.5" mm"  along high-gradient boundary interfaces (crucible inner surface and contact planes). 
